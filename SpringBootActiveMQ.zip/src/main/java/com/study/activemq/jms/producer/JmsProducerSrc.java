package com.study.activemq.jms.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.study.activemq.util.MapMessageConverter;

@Component
public class JmsProducerSrc {

	@Autowired
	@Qualifier("srcJmsTemplate")
	JmsTemplate jmsTemplate;

	@Value("${src.activemq.queue}")
	String queue;

	public void send(Object obj) {
		jmsTemplate.send(queue, new MapMessageConverter(obj));
	}
}