package com.study.activemq.jms.consumer;

import javax.jms.JMSException;
import javax.jms.MapMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.study.activemq.jms.producer.JmsProducerDest;
import com.study.activemq.model.Customer;
import com.study.activemq.model.MessageStorage;

@Component
public class JmsConsumerSrc {

	@Autowired
	private MessageStorage storage;

	@Autowired
	JmsProducerDest jmsProducer;

	@JmsListener(destination = "${src.activemq.queue}", containerFactory = "jsaFactory")
	public void onMessage(MapMessage message) throws JMSException {

		// extract from message
		Object obj = extractPayload(message);
		System.out.println(obj.toString());

		// store
		storage.add(obj);

		// produce new message to destination
		jmsProducer.send(obj);
	}

	private Object extractPayload(MapMessage message) throws JMSException {
		System.out.println("Extracting from message: " + message);

		return new Customer(message.getLong("id"), message.getString("firstname"), message.getString("lastname"),
				message.getInt("age"));
	}

}