package com.study.activemq.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.core.MessageCreator;

public class MapMessageConverter implements MessageCreator {

	Object obj;

	public MapMessageConverter(Object obj) {
		super();
		this.obj = obj;
	}

	@Override
	public Message createMessage(Session session) throws JMSException {
		return toMapMessage(obj, session.createMapMessage());
	}

	private MapMessage toMapMessage(Object ob, MapMessage message) throws JMSException {
		Class cls = ob.getClass();
		message.setStringProperty("_type", cls.getName());

		for (Field field : cls.getDeclaredFields()) {
			for (Method method : cls.getMethods()) {
				if (((method.getName().startsWith("get"))
						&& (method.getName().length() == (field.getName().length() + 3)))
						|| ((method.getName().startsWith("is"))
								&& (method.getName().length() == (field.getName().length() + 2)))) {
					if (method.getName().toLowerCase().endsWith(field.getName().toLowerCase())) {
						try {
							if (field.getType().getSimpleName().toLowerCase().endsWith("integer"))
								message.setInt(field.getName(), (int) method.invoke(ob));
							else if (field.getType().getSimpleName().toLowerCase().endsWith("long"))
								message.setLong(field.getName(), (long) method.invoke(ob));
							else if (field.getType().getSimpleName().toLowerCase().endsWith("string"))
								message.setString(field.getName(), (String) method.invoke(ob));
							else if (field.getType().getSimpleName().toLowerCase().endsWith("boolean"))
								message.setBoolean(field.getName(), (boolean) method.invoke(ob));
							else if (field.getType().getSimpleName().toLowerCase().endsWith("double"))
								message.setDouble(field.getName(), (double) method.invoke(ob));
							else if (field.getType().getSimpleName().toLowerCase().endsWith("float"))
								message.setFloat(field.getName(), (float) method.invoke(ob));
							else
								message.setObject(field.getName(), method.invoke(ob));
						} catch (IllegalAccessException | InvocationTargetException | IllegalArgumentException
								| JMSException e) {
							System.err.println(e.getMessage());
						}
					}
				}
			}
		}
		return message;
	}
}
