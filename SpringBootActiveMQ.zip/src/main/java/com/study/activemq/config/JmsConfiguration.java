package com.study.activemq.config;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQSslConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;

@EnableJms
@Configuration
public class JmsConfiguration {

	@Value("${src.activemq.broker.url}")
	String srcBrokerUrl;

	@Value("${src.activemq.borker.username}")
	String srcUserName;

	@Value("${src.activemq.borker.password}")
	String srcPassword;

	@Value("${dest.activemq.broker.url}")
	String destBrokerUrl;

	@Value("${dest.activemq.borker.username}")
	String destUserName;

	@Value("${src.activemq.borker.password}")
	String destPassword;

	@Value("${src.activemq.ssl.keystore.path}")
	String srcKeystore;

	@Value("${src.activemq.ssl.keystore.value}")
	String srcKeystorePass;

	@Value("${src.activemq.ssl.truststore.path}")
	String srcTruststore;

	@Value("${src.activemq.ssl.truststore.value}")
	String srcTruststorePass;

	@Value("${dest.activemq.ssl.keystore.path}")
	String destKeystore;

	@Value("${dest.activemq.ssl.keystore.value}")
	String destKeystorePass;

	@Value("${dest.activemq.ssl.truststore.path}")
	String destTruststore;

	@Value("${dest.activemq.ssl.truststore.value}")
	String destTruststorePass;

	@Value("${src.activemq.max.connections:1}")
	String srcMaxPooledConnections;

	@Value("${dest.activemq.max.connections:1}")
	String destMaxPooledConnections;

	@Bean
	@Primary
	public ConnectionFactory srcConnectionFactory() throws Exception {
		ActiveMQSslConnectionFactory connectionFactory = new ActiveMQSslConnectionFactory();
		connectionFactory.setBrokerURL(srcBrokerUrl);
		connectionFactory.setUserName(srcUserName);
		connectionFactory.setPassword(srcPassword);
		connectionFactory.setKeyStore(srcKeystore);
		connectionFactory.setKeyStorePassword(srcKeystorePass);
		connectionFactory.setTrustStore(srcTruststore);
		connectionFactory.setTrustStorePassword(srcTruststorePass);
		PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory(connectionFactory);
		pooledConnectionFactory.setMaxConnections(Integer.parseInt(srcMaxPooledConnections));
		return pooledConnectionFactory;
	}
	
	@Bean
	public ConnectionFactory destConnectionFactory() throws Exception {
		ActiveMQSslConnectionFactory connectionFactory = new ActiveMQSslConnectionFactory();
		connectionFactory.setBrokerURL(destBrokerUrl);
		connectionFactory.setUserName(destUserName);
		connectionFactory.setPassword(destPassword);
		connectionFactory.setKeyStore(destKeystore);
		connectionFactory.setKeyStorePassword(destKeystorePass);
		connectionFactory.setTrustStore(destTruststore);
		connectionFactory.setTrustStorePassword(destTruststorePass);
		PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory(connectionFactory);
		pooledConnectionFactory.setMaxConnections(Integer.parseInt(destMaxPooledConnections));
		return pooledConnectionFactory;
	}
	
	@Bean
	public JmsListenerContainerFactory<?> jsaFactory(ConnectionFactory connectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setMessageConverter(jacksonJmsMessageConverter());
		configurer.configure(factory, connectionFactory);
		return factory;
	}

	@Bean
	public MessageConverter jacksonJmsMessageConverter() {
		MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
		converter.setTargetType(MessageType.MAP);
		converter.setTypeIdPropertyName("_type");
		return converter;
	}

	@Bean(name = "srcJmsTemplate")
	public JmsTemplate srcJmsTemplate() throws Exception {
		return new JmsTemplate(srcConnectionFactory());
	}

	@Bean(name = "destJmsTemplate")
	public JmsTemplate destJmsTemplate() throws Exception {
		return new JmsTemplate(destConnectionFactory());
	}

}