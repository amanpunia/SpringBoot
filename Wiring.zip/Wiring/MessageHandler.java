package com.study.activemq.handler;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.netspend.samsungdata.dto.TransactionData;
import com.netspend.samsungdata.dto.TransactionRequest;
import com.netspend.samsungdata.dto.TransactionType;
import com.netspend.samsungdata.exception.ValidationException;

@Component
public class MessageHandler {

	@Autowired
	@Qualifier(value = "topupTransactionHandler")
	private TransactionHandler topupTransactionHandler;

	@Autowired
	@Qualifier(value = "p2pTransactionHandler")
	private TransactionHandler p2pTransactionHandler;

	@Autowired
	@Qualifier(value = "defaultTransactionHandler")
	private TransactionHandler defaultTransactionHandler;

	public TransactionData onMessage(String type) throws ValidationException {

		TransactionRequest request = null;
		TransactionData response = null;
		if (isValidType(type)) {
			if (TransactionType.P2P.getName().equals(type)) {
				response = p2pTransactionHandler.save(request);
			} else if (TransactionType.TOPUP.getName().equals(type)) {
				response = topupTransactionHandler.save(request);
			} else {
				response = defaultTransactionHandler.save(request);
			}
		} else {
			throw new ValidationException();
		}
		return response;
	}

	private boolean isValidType(String type) {
		if (type != null) {
			for (TransactionType txType : TransactionType.values()) {
				if (type.equals(txType.getName()))
					return true;
			}
		}
		return false;
	}
}
