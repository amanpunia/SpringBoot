package com.netspend.samsungdata.dto;

public enum TransactionType {

	P2P("p2p"), TOPUP("topup"), OTHERS("others");

	private String name;

	TransactionType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
