package com.study.activemq.handler;

import com.netspend.samsungdata.dto.TransactionData;
import com.netspend.samsungdata.dto.TransactionRequest;
import com.netspend.samsungdata.exception.ValidationException;

public interface TransactionHandler {

	public TransactionData save(TransactionRequest request) throws ValidationException;
	
}
