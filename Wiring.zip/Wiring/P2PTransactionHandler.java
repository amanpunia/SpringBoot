package com.study.activemq.handler;

import com.netspend.samsungdata.dto.TransactionData;
import com.netspend.samsungdata.dto.TransactionRequest;
import com.netspend.samsungdata.exception.ValidationException;

public class P2PTransactionHandler implements TransactionHandler {

	@Override
	public TransactionData save(TransactionRequest request) throws ValidationException {
		TransactionData data = new TransactionData();
		data.setData("P2P handler");
		return data;
	}

}
