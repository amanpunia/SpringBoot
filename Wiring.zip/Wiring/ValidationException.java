package com.netspend.samsungdata.exception;

public class ValidationException extends Exception{

}
