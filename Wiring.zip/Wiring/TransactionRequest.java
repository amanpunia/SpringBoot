package com.netspend.samsungdata.dto;

public class TransactionRequest {

	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
