package com.study.activemq.handler;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TransactionHandlerConfig {

	@Bean
	public TransactionHandler topupTransactionHandler() {
		return new TopupTransactionHandler();
	}

	@Bean
	public TransactionHandler p2pTransactionHandler() {
		return new P2PTransactionHandler();
	}

	@Bean
	public TransactionHandler defaultTransactionHandler() {
		return new DefaultTransactionHandler();
	}
}
